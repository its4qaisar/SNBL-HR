from django import forms
from .models import Emp

class EmpForm(forms.ModelForm):
    class Meta:
        model = Emp
        fields = "__all__"
    
    GENDER_CHOICES = [
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Other', 'Other'),
    ]

    CASE_STATUS = [
        ('Hiring Inprocess', 'Hiring Inprocess'),
        ('Offer Letter Issued', 'Offer Letter Issued'),
        ('Offer Rejected', 'Offer Rejected'),
        ('Joining Inprocess', 'Joining Inprocess'),
        ('Onboard', 'Onboard'),
        ('Resign', 'Resign'),
    ]

    REGIONS = [ 
        ("City Lahore", "City Lahore"), 
        ("Faisalabad" , "Faisalabad"), 
        ("Gujranwala" , "Gujranwala"), 
        ("Gulberg Lahore", "Gulberg Lahore"),
        ("Mall Lahore", "Mall Lahore"), 
        ("Model Town", "Model Town"), 
]
    
    BRANCHES = [
    ("Cavalry Ground-0042", "Cavalry Ground-0042"),
    ("Chungi Amer Sadhu-0068", "Chungi Amer Sadhu-0068"),
    ("Kana Kacha -0158", "Kana Kacha -0158"),
    ("Safari Garden Br-0284", "Safari Garden Br-0284"),
    ("KhayabanIqbal Br.-0462", "KhayabanIqbal Br.-0462"),
    ("Defence Br Lahore-0011", "Defence Br Lahore-0011"),
    ("Airport Road Br.-0085", "Airport Road Br.-0085"),
    ("Zarrar Shaheed Rd-0144", "Zarrar Shaheed Rd-0144"),
    ("DHA Ph-VIII Br.-0348", "DHA Ph-VIII Br.-0348"),
    ("State Life Br.-0349", "State Life Br.-0349"),
    ("DHA Phase III LHR-0067", "DHA Phase III LHR-0067"),
    ("DHA Phase-IV LHR-0192", "DHA Phase-IV LHR-0192"),
    ("Lalik Chowk Br.-0327", "Lalik Chowk Br.-0327"),
    ("DHA RAYA LHR Br.-0361", "DHA RAYA LHR Br.-0361"),
    ("HADYARA Br.-0383", "HADYARA Br.-0383"),
    ("Badian Road LHR-0095", "Badian Road LHR-0095"),
    ("DHA Phase-V LHR-0252", "DHA Phase-V LHR-0252"),
    ("Walton Road Br.-0258", "Walton Road Br.-0258"),
    ("Park Avenue Br.-0344", "Park Avenue Br.-0344"),
    ("Heir Br.-0393", "Heir Br.-0393"),
    ("Shahbaz Khan Rd-0127", "Shahbaz Khan Rd-0127"),
    ("Ellahabad-0236", "Ellahabad-0236"),
    ("Khudian-0250", "Khudian-0250"),
    ("KOT RADHA KISHN-0356", "KOT RADHA KISHN-0356"),
    ("Mustafa Abad Br.-0430", "Mustafa Abad Br.-0430"),
    ("Chiniot-0178", "Chiniot-0178"),
    ("Gojra Branch-0199", "Gojra Branch-0199"),
    ("Painsera-0229", "Painsera-0229"),
    ("Pull-111 Br. SGD-0275", "Pull-111 Br. SGD-0275"),
    ("Chenab Nagar Br.-0365", "Chenab Nagar Br.-0365"),
    ("Main FSD-0008", "Main FSD-0008"),
    ("Ghulam Muhamadabd-0129", "Ghulam Muhamadabd-0129"),
    ("Madina Town FSD-0279", "Madina Town FSD-0279"),
    ("Narwala Bngla Br.-0469", "Narwala Bngla Br.-0469"),
    ("Peoples Colony Br-0066", "Peoples Colony Br-0066"),
    ("Jaranwala Branch-0176", "Jaranwala Branch-0176"),
    ("Civil Lines-FSD-0243",  "Civil Lines - FSD-0243"),
    ("Khurrianwala Br.-0245", "Khurrianwala Br.-0245"),
    ("FIEDMC Branch Br.-0453", "FIEDMC Branch Br.-0453"),
    ("Dhaandra Br.-0475", "Dhaandra Br.-0475"),
    ("Main GUJ-0007", "Main GUJ-0007"),
    ("Kamoke Branch-0185", "Kamoke Branch-0185"),
    ("Wapda Town GUJ-0204", "Wapda Town GUJ-0204"),
    ("Muridke-0216", "Muridke-0216"),
    ("Sheikhupura Rd Br-0336", "Sheikhupura Rd Br-0336"),
    ("Eminabad Br.-0353", "Eminabad Br.-0353"),
    ("D. C. Colony Br.-0354", "D. C. Colony Br.-0354"),
    ("Shakargarh Br.-0459", "Shakargarh Br.-0459"),
    ("SIE Br.Sialkot-0009", "SIE Br.Sialkot-0009"),
    ("Ghakkar Mandi-0153", "Ghakkar Mandi-0153"),
    ("Daska-0208", "Daska-0208"),
    ("Daska Road Br.-0294", "Daska Road Br.-0294"),
    ("Paris Rod SKT Br.-0364", "Paris Rod SKT Br.-0364"),
    ("Ugoki Br.-0404", "Ugoki Br.-0404"),
    ("Circular Road Br.-0405", "Circular Road Br.-0405"),
    ("Sambrial Branch-0151", "Sambrial Branch-0151"),
    ("Godhpur-0209", "Godhpur-0209"),
    ("Narowal-0254", "Narowal-0254"),
    ("Wazirabad Rd Skt-0346", "Wazirabad Rd Skt-0346"),
    ("Pasrur Br.-0355", "Pasrur Br.-0355"),
    ("Smart Cty SKT Br.-0384", "Smart Cty SKT Br.-0384"),
    ("Hajipura Br.-0406", "Hajipura Br.-0406"),
    ("Main Br Wazirabad-0021", "Main Br Wazirabad-0021"),
    ("Hafizabad-0106", "Hafizabad-0106"),
    ("Pasrur Rd Br-0118", "Pasrur Rd Br-0118"),
    ("Jalal Pur Bhatia-0224", "Jalal Pur Bhatia-0224"),
    ("Citi H.S Br.-0394", "Citi H.S Br.-0394"),
    ("GTR Wazirabad Br.-0419", "GTR Wazirabad Br.-0419"),
    ("Raja Road SKT Br.-0428", "Raja Road SKT Br.-0428"),
    ("Gulberg Br. LHR-0015", "Gulberg Br. LHR-0015"),
    ("BK-L Gulberg -III 0253", "BK-L Gulberg -III 0253"),
    ("Main Boulevard Br-0290", "Main Boulevard Br-0290"),
    ("Kahna Nau Br.-0415", "Kahna Nau Br.-0415"),
    ("Main Market Br.-0420", "Main Market Br.-0420"),
    ("Allama Iqbal Town-0047", "Allama Iqbal Town-0047"),
    ("Wahdat Road LHR-0072", "Wahdat Road LHR-0072"),
    ("Islampura LHR-0113", "Islampura LHR-0113"),
    ("Expo Centre LHR-0232", "Expo Centre LHR-0232"),
    ("Faisal Town Br.-0259", "Faisal Town Br.-0259"),
    ("Thokar Niaz Baig-0054", "Thokar Niaz Baig-0054"),
    ("Sabzazar Br. LHR-0179", "Sabzazar Br. LHR-0179"),
    ("Karim Block LHR-0266", "Karim Block LHR-0266"),
    ("Canal View LHR Br-0323", "Canal View LHR Br-0323"),
    ("LDA Avenue-I Br.-0392", "LDA Avenue-I Br.-0392"),
    ("Manga Rwnd Rd BR.-0456", "Manga Rwnd Rd BR.-0456"),
    ("Gunpat Road LHR-0081", "Gunpat Road LHR-0081"),
    ("Mughalpura LHR-0096", "Mughalpura LHR-0096"),
    ("Jail Road Br. LHR-0196", "Jail Road Br. LHR-0196"),
    ("Main Br. Lahore-0001", "Main Br. Lahore-0001"),
    ("Garhi Shahu LHR-0142", "Garhi Shahu LHR-0142"),
    ("Montgomery Road-0220", "Montgomery Road-0220"),
    ("Sheikhupura Br.-0017", "Sheikhupura Br.-0017"),
    ("Ravi Road Br. LHR-0091", "Ravi Road Br. LHR-0091"),
    ("Shahdra Br. LHR-0092", "Shahdra Br. LHR-0092"),
    ("Nankana Sahib Br.-0131", "Nankana Sahib Br.-0131"),
    ("Sharaqpur Br.-0347", "Sharaqpur Br.-0347"),
    ("Farooqabad Br.-0360", "Farooqabad Br.-0360"),
    ("Sangla Hill Br.-0396", "Sangla Hill Br.-0396"),
    ("Omega Br.-0409", "Omega Br.-0409"),
    ("Kot Abdul Br.-0412", "Kot Abdul Br.-0412"),
    ("Attari Br.-0414", "Attari Br.-0414"),
    ("Feroze Watwan Br.-0429", "Feroze Watwan Br.-0429"),
    ("Shah Kot Br.-0431", "Shah Kot Br.-0431"),
    ("Safdarabad Br.-0435", "Safdarabad Br.-0435"),
    ("Qila Sattar Br.-0455", "Qila Sattar Br.-0455"),
    ("Circular Rd. LHR-0026", "Circular Rd. LHR-0026"),
    ("Baghbanpura LHR-0053", "Baghbanpura LHR-0053"),
    ("Badami Bagh LHR-0198", "Badami Bagh LHR-0198"),
    ("Shah Alam Market-0238", "Shah Alam Market-0238"),
    ("Shadbagh LHR Br.-0338", "Shadbagh LHR Br.-0338"),
    ("Bahria Town Br.-0225", "Bahria Town Br.-0225"),
    ("Defence Road Br-0269", "Defence Road Br-0269"),
    ("Sundar Ind Est Br-0305", "Sundar Ind Est Br-0305"),
    ("Valencia Town Br.-0343", "Valencia Town Br.-0343"),
    ("Sukh Chayn Br.-0388", "Sukh Chayn Br.-0388"),
    ("Chung Br.-0389", "Chung Br.-0389"),
    ("Bahria Orchrd Br.-0390", "Bahria Orchrd Br.-0390"),
    ("Dina Nath Br.-0448", "Dina Nath Br.-0448"),
    ("Peco Road Br. LHR-0036", "Peco Road Br. LHR-0036"),
    ("Ghazi Chowk LHR-0058", "Ghazi Chowk LHR-0058"),
    ("College Road Br-0195", "College Road Br-0195"),
    ("Wapda Town LHR-0234", "Wapda Town LHR-0234"),
    ("EME Society Br.-0302", "EME Society Br.-0302"),
    ("Khyban-e-Jnah Br.-0352", "Khyban-e-Jnah Br.-0352"),
    ("Manga Mandi LHR-0094", "Manga Mandi LHR-0094"),
    ("Raiwind Branch-0288", "Raiwind Branch-0288"),
    ("Lake City Br.-0303", "Lake City Br.-0303"),
    ("Phool Nagar Br.-0357", "Phool Nagar Br.-0357"),
    ("Fazaia Br. LHR-0368", "Fazaia Br. LHR-0368"),
    ("Park View LHR BR.-0458", "Park View LHR BR.-0458"),
    ("Model Town Br LHR-0035", "Model Town Br LHR-0035"),
    ("Johar Town LHR-0071", "Johar Town LHR-0071"),
    ("Hamdard Chowk LHR-0157", "Hamdard Chowk LHR-0157"),
    ("K-Model Town Br.-0326", "K-Model Town Br.-0326")
]


    fname = forms.CharField(
        widget=forms.TextInput(attrs={'placeholder': 'Enter First Name', 'class': 'form-control'})
    )
    lname = forms.CharField(
        widget=forms.TextInput(attrs={'placeholder': 'Enter Last Name', 'class': 'form-control'})
    )

    cnic = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter CNIC'})
    )

    gender = forms.ChoiceField(
        choices=GENDER_CHOICES, 
        widget=forms.Select(attrs={'class': 'form-control'})
    )

    phone_number = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Phone Number'})
    )

    date_of_birth = forms.DateField(
        widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date', 'placeholder': 'Date of Birth'})
    )

    designation = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Designation'})
    )

    branch_name = forms.ChoiceField(
        choices=BRANCHES, 
        widget=forms.Select(attrs={'class': 'form-control'})
    )

    region_name = forms.ChoiceField(
        choices=REGIONS, 
        widget=forms.Select(attrs={'class': 'form-control'})
    )



    GM_remarks = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter GM Remarks'}),
        required=False
    )

    HR_remarks = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter HR Remarks'}),
        required=False
    )

    case_status = forms.ChoiceField(
        choices=CASE_STATUS, 
        widget=forms.Select(attrs={'class': 'form-control'})
    )

    region_case_forward_date = forms.DateField(
        widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date', 'placeholder': 'Region Forwarded Case'}),
    )

    group_case_forward_date = forms.DateField(
        widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date', 'placeholder': 'Group Forwarded Case'})
    )

    offer_letter_receiving_date = forms.DateField(
        widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date', 'placeholder': 'Offer Letter Receiving Date'})
    )

candidate_picture = forms.ImageField(
    widget=forms.FileInput(attrs={'class': 'form-control-file', 'placeholder': 'Upload Profile Picture'})
)

