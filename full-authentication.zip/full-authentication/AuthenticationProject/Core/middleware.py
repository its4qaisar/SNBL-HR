from django.shortcuts import redirect
from django.urls import reverse
from django.conf import settings
from .models import PasswordReset,Emp,UserProfile
from django.utils.deprecation import MiddlewareMixin
from django.http import HttpResponseForbidden

# middleware.py

class PreventUnauthorizedAccessMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if not request.user.is_authenticated:
            allowed_urls = [reverse('login'), reverse('register')]
            if request.path not in allowed_urls:
                return redirect('login')
        response = self.get_response(request)
        return response
    

class CheckLoginMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if not request.user.is_authenticated and not request.path.startswith('/login/'):
            return redirect('login')

        response = self.get_response(request)
        return response
    

class RegionRestrictionMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.user.is_authenticated:
            try:
                user_region = request.user.userprofile.region_name  # Now it will work
            except UserProfile.DoesNotExist:
                user_region = None

            if user_region:
                # Your region-based logic here
                pass

        response = self.get_response(request)
        return response