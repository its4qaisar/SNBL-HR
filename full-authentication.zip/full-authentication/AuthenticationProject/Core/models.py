from django.db import models
from django.contrib.auth.models import User
from django.db import IntegrityError
from datetime import timedelta
from django.db import models
from django.utils import timezone
from django.db import models, IntegrityError
import uuid

class PasswordReset(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    reset_id = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    created_when = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Password reset for {self.user.username} at {self.created_when}"


class Emp(models.Model):
    STATUS = [
        ('Hiring Inprocess', 'Hiring Inprocess'),
        ('Offer Letter Issued', 'Offer Letter Issued'),
        ('Offer Rejected', 'Offer Rejected'),
        ('Joining Inprocess', 'Joining Inprocess'),
        ('Onboard', 'Onboard'),
        ('Resign', 'Resign'),
    ]

    REGIONS = [ 
        ("City Lahore", "City Lahore"), 
        ("Faisalabad", "Faisalabad"), 
        ("Gujranwala", "Gujranwala"), 
        ("Gulberg Lahore", "Gulberg Lahore"),
        ("Mall Lahore", "Mall Lahore"), 
        ("Model Town", "Model Town"), 
    ]

    GENDER = [
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Other', 'Other'),
    ]

    BRANCHES = [
        ("Cavalry Ground-0042",   "Cavalry Ground-0042"),
        ("Chungi Amer Sadhu-0068",  "Chungi Amer Sadhu-0068"),
        ("Kana Kacha-0158",   "Kana Kacha-0158"),
        ("Safari Garden Br-0284",   "Safari Garden Br-0284"),
        ("KhayabanIqbal Br.-0462",    "KhayabanIqbal Br.-0462"),
        ("Defence Br Lahore-0011",   "Defence Br Lahore-0011"),
        ("Airport Road Br.-0085",   "Airport Road Br.-0085"),
        ("Zarrar Shaheed Rd-0144",    "Zarrar Shaheed Rd-0144"),
        ("DHA Ph-VIII Br.-0348",    "DHA Ph-VIII Br.-0348"),
        ("State Life Br.-0349",    "State Life Br.-0349"),
        ("DHA Phase III LHR-0067",     "DHA Phase III LHR-0067"),
        ("DHA Phase-IV LHR-0192",    "DHA Phase-IV LHR-0192"),
        ("Lalik Chowk Br.-0327",    "Lalik Chowk Br.-0327"),
        ("DHA RAYA LHR Br.-0361",     "DHA RAYA LHR Br.-0361"),
        ("HADYARA Br.-0383",       "HADYARA Br.-0383"),
        ("Badian Road LHR-0095",    "Badian Road LHR-0095"),
        ("DHA Phase-V LHR-0252",    "DHA Phase-V LHR-0252"),
        ("Walton Road Br.-0258",    "Walton Road Br.-0258"),
        ("Park Avenue Br.-0344",    "Park Avenue Br.-0344"),
        ("Heir Br.-0393",           "Heir Br.-0393"),
        ("Shahbaz Khan Rd-0127",   "Shahbaz Khan Rd-0127"),
        ("Ellahabad-0236",         "Ellahabad-0236"),
        ("Khudian-0250",           "Khudian-0250"),
        ("KOT RADHA KISHN-0356",   "KOT RADHA KISHN-0356"),
        ("Mustafa Abad Br.-0430",   "Mustafa Abad Br.-0430"),
        ("Chiniot-0178",             "Chiniot-0178"),
        ("Gojra Branch-0199",        "Gojra Branch-0199"),
        ("Painsera-0229",             "Painsera-0229"),
        ("Pull-111 Br. SGD-0275",      "Pull-111 Br. SGD-0275"),
        ("Chenab Nagar Br.-0365",       "Chenab Nagar Br.-0365"),
        ("Main FSD-0008",                "Main FSD-0008"),
        ("Ghulam Muhamadabd-0129",    "Ghulam Muhamadabd-0129"),
        ("Madina Town FSD-0279",     "Madina Town FSD-0279"),
        ("Narwala Bngla Br.-0469",  "Narwala Bngla Br.-0469"),
        ("Peoples Colony Br-0066",  "Peoples Colony Br-0066"),
        ("Jaranwala Branch-0176",  "Jaranwala Branch-0176"),
        ("Civil Lines-FSD-0243",      "Civil Lines-FSD-0243"),
        ("Khurrianwala Br.-0245",     "Khurrianwala Br.-0245"),
        ("FIEDMC Branch Br.-0453",     "FIEDMC Branch Br.-0453"),
        ("Dhaandra Br.-0475",        "Dhaandra Br.-0475"),
        ("Main GUJ-0007",           "Main GUJ-0007"),
        ("Kamoke Branch-0185",    "Kamoke Branch-0185"),
        ("Wapda Town GUJ-0204",    "Wapda Town GUJ-0204"),
        ("Muridke-0216",           "Muridke-0216"),
        ("Sheikhupura Rd Br-0336",   "Sheikhupura Rd Br-0336"),
        ("Eminabad Br.-0353",     "Eminabad Br.-0353"),
        ("D. C. Colony Br.-0354",   "D. C. Colony Br.-0354"),
        ("Shakargarh Br.-0459",     "Shakargarh Br.-0459"),
        ("SIE Br. Sialkot-0009",    "SIE Br. Sialkot-0009"),
        ("Ghakkar Mandi-0153",     "Ghakkar Mandi-0153"),
        ("Daska-0208",       "Daska-0208"),
        ("Daska Road Br.-0294",    "Daska Road Br.-0294"),
        ("Paris Rod SKT Br.-0364",     "Paris Rod SKT Br.-0364"),
        ("Ugoki Br.-0404",       "Ugoki Br.-0404"),
        ("Circular Road Br.-0405",   "Circular Road Br.-0405"),
        ("Sambrial Branch-0151",    "Sambrial Branch-0151"),
        ("Godhpur-0209",      "Godhpur-0209"),
        ("Narowal-0254",      "Narowal-0254"),
        ("Wazirabad Rd Skt-0346",   "Wazirabad Rd Skt-0346"),
        ("Pasrur Br.-0355",    "Pasrur Br.-0355"),
        ("Smart Cty SKT Br.-0384",    "Smart Cty SKT Br.-0384"),
        ("Hajipura Br.-0406",     "Hajipura Br.-0406"),
        ("Main Br Wazirabad-0021",    "Main Br Wazirabad-0021"),
        ("Hafizabad-0106",    "Hafizabad-0106"),
        ("Pasrur Rd Br-0118",    "Pasrur Rd Br-0118"),
        ("Jalal Pur Bhatia-0224",   "Jalal Pur Bhatia-0224"),
        ("Citi H.S Br.-0394",    "Citi H.S Br.-0394"),
        ("GTR Wazirabad Br.-0419",   "GTR Wazirabad Br.-0419"),
        ("Raja Road SKT Br.-0428",   "Raja Road SKT Br.-0428"),
        ("Gulberg Br. LHR-0015",   "Gulberg Br. LHR-0015"),
        ("BK-L Gulberg-III-0253",   "BK-L Gulberg-III-0253"),
        ("Main Boulevard Br-0290",   "Main Boulevard Br-0290"),
        ("Kahna Nau Br.-0415",    "Kahna Nau Br.-0415"),
        ("Main Market Br.-0420",    "Main Market Br.-0420"),
        ("Allama Iqbal Town-0047",   "Allama Iqbal Town-0047"),
        ("Wahdat Road LHR-0072",   "Wahdat Road LHR-0072"),
        ("Islampura LHR-0113",    "Islampura LHR-0113"),
        ("Expo Centre LHR-0232",   "Expo Centre LHR-0232"),
        ("Faisal Town Br.-0259",  "Faisal Town Br.-0259"),
        ("Thokar Niaz Baig-0054",  "Thokar Niaz Baig-0054"),
        ("Sabzazar Br. LHR-0179",  "Sabzazar Br. LHR-0179"),
        ("Karim Block LHR-0266",  "Karim Block LHR-0266"),
        ("Canal View LHR Br-0323",  "Canal View LHR Br-0323"),
        ("LDA Avenue-I Br.-0392",   "LDA Avenue-I Br.-0392"),
        ("Manga Rwnd Rd BR.-0456",   "Manga Rwnd Rd BR.-0456"),
        ("Gunpat Road LHR-0081",     "Gunpat Road LHR-0081"),
        ("Mughalpura LHR-0096",    "Mughalpura LHR-0096"),
        ("Jail Road Br. LHR-0196",   "Jail Road Br. LHR-0196"),
        ("Main Br. Lahore-0001",    "Main Br. Lahore-0001"),
        ("Garhi Shahu LHR-0142",    "Garhi Shahu LHR-0142"),
        ("Montgomery Road-0220",    "Montgomery Road-0220"),
        ("Sheikhupura Br.-0017",   "Sheikhupura Br.-0017"),
        ("Ravi Road Br. LHR-0091",   "Ravi Road Br. LHR-0091"),
        ("Shahdra Br. LHR-0092",    "Shahdra Br. LHR-0092"),
        ("Nankana Sahib Br.-0131",   "Nankana Sahib Br.-0131"),
        ("Sharaqpur Br.-0347",    "Sharaqpur Br.-0347"),
        ("Farooqabad Br.-0360",   "Farooqabad Br.-0360"),
        ("Sangla Hill Br.-0396",   "Sangla Hill Br.-0396"),
        ("Omega Br.-0409",       "Omega Br.-0409"),
        ("Kot Abdul Br.-0412",   "Kot Abdul Br.-0412"),
        ("Attari Br.-0414",    "Attari Br.-0414"),
        ("Feroze Watwan Br.-0429",    "Feroze Watwan Br.-0429"),
        ("Shah Kot Br.-0431",       "Shah Kot Br.-0431"),
        ("Safdarabad Br.-0435",    "Safdarabad Br.-0435"),
        ("Qila Sattar Br.-0455",    "Qila Sattar Br.-0455"),
        ("Circular Rd. LHR-0026",   "Circular Rd. LHR-0026"),
        ("Baghbanpura LHR-0053",    "Baghbanpura LHR-0053"),
        ("Badami Bagh LHR-0198",   "Badami Bagh LHR-0198"),
        ("Shah Alam Market-0238",   "Shah Alam Market-0238"),
        ("Shadbagh LHR Br.-0338",   "Shadbagh LHR Br.-0338"),
        ("Bahria Town Br.-0225",   "Bahria Town Br.-0225"),
        ("Defence Road Br-0269",   "Defence Road Br-0269"),
        ("Sundar Ind Est Br-0305",  "Sundar Ind Est Br-0305"),
        ("Valencia Town Br.-0343",  "Valencia Town Br.-0343"),
        ("Sukh Chayn Br.-0388",   "Sukh Chayn Br.-0388"),
        ("Chung Br.-0389",       "Chung Br.-0389"),
        ("Bahria Orchrd Br.-0390",   "Bahria Orchrd Br.-0390"),
        ("Dina Nath Br.-0448",     "Dina Nath Br.-0448"),
        ("Peco Road Br. LHR-0036",    "Peco Road Br. LHR-0036"),
        ("Ghazi Chowk LHR-0058",   "Ghazi Chowk LHR-0058"),
        ("College Road Br-0195",    "College Road Br-0195"),
        ("Wapda Town LHR-0234",    "Wapda Town LHR-0234"),
        ("EME Society Br.-0302",    "EME Society Br.-0302"),
        ("Khyban-e-Jnah Br.-0352",    "Khyban-e-Jnah Br.-0352"),
        ("Manga Mandi LHR-0094",   "Manga Mandi LHR-0094"),
        ("Raiwind Branch-0288",   "Raiwind Branch-0288"),
        ("Lake City Br.-0303",   "Lake City Br.-0303"),
        ("Phool Nagar Br.-0357",   "Phool Nagar Br.-0357"),
        ("Fazaia Br. LHR-0368",  "Fazaia Br. LHR-0368"),
        ("Park View LHR BR.-0458",   "Park View LHR BR.-0458"),
        ("Model Town Br LHR-0035",  "Model Town Br LHR-0035"),
        ("Johar Town LHR-0071",   "Johar Town LHR-0071"),
        ("Hamdard Chowk LHR-0157",   "Hamdard Chowk LHR-0157"),
        ("K-Model Town Br.-0326",   "K-Model Town Br.-0326"),
    ]

    fname = models.CharField(max_length=255, default='unknown')
    lname = models.CharField(max_length=255, default='unknown')
    cnic = models.CharField(max_length=255)
    gender = models.CharField(max_length=10, choices=GENDER)
    phone_number = models.CharField(max_length=20)
    date_of_birth = models.DateField(null=True, blank=True)
    designation = models.CharField(max_length=255)
    branch_name = models.CharField(
        max_length=200,
        choices=BRANCHES,
        default="Select the Branch",null=True, blank=True
    )
    region_name = models.CharField(
        max_length=100,
        choices=REGIONS,
        default="Select the Region", null=True, blank=True
    )
    GM_remarks = models.TextField(max_length=200, blank=True)
    HR_remarks = models.TextField(max_length=200, blank=True)
    case_status = models.CharField(max_length=50, choices=STATUS)
    region_case_forward_date = models.DateField(null=True, blank=True)
    group_case_forward_date = models.DateField(null=True, blank=True)
    offer_letter_receiving_date = models.DateField(null=True, blank=True)
    candidate_picture = models.ImageField(upload_to="images/", null=True, blank=True,)


    @property
    def tat_group_region(self):
        if self.group_case_forward_date and self.region_case_forward_date:
            return self.group_case_forward_date - self.region_case_forward_date
        return None

    @property
    def tat_hr_group(self):
        if self.offer_letter_receiving_date and self.group_case_forward_date:
            return self.offer_letter_receiving_date - self.group_case_forward_date
        return None

    def __str__(self):
        return f"{self.fname} {self.lname}"

    # Override the save method to capitalize certain fields automatically
    def save(self, *args, **kwargs):
        self.fname = self.fname.capitalize()
        self.lname = self.lname.capitalize()
        self.designation = self.designation.upper()
        # Removed capitalization for fields with predefined choices
        self.GM_remarks = self.GM_remarks.capitalize()
        self.HR_remarks = self.HR_remarks.capitalize()
        super().save(*args, **kwargs)

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    region_name = models.CharField(
        max_length=100, 
        choices=(
            ("Central-I", "Central-I"),
            ("City Lahore", "City Lahore"),
            ("Faisalabad", "Faisalabad"),
            ("Gujranwala", "Gujranwala"),
            ("Gulberg Lahore", "Gulberg Lahore"),
            ("Mall Lahore", "Mall Lahore"),
            ("Model Town", "Model Town"),
            # Add more regions as needed
        )
    )

    def __str__(self):
        return self.user.username




class Todo(models.Model):
    TASK_TYPES = [
        ('work', 'Work'),
        ('personal', 'Personal'),
        ('other', 'Other'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    task_type = models.CharField(max_length=10, choices=TASK_TYPES, default='other')
    description = models.TextField()
    due_date = models.DateTimeField(default=timezone.now)
    is_completed = models.BooleanField(default=False)
    reminder_set = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.description} ({self.get_task_type_display()})"

    def is_due_soon(self):
        """
        Check if the task is due within the next 10 minutes.
        """
        now = timezone.now()
        return self.due_date <= now + timezone.timedelta(minutes=10) and not self.is_completed

    def schedule_reminder(self):
        """
        Schedule a reminder for the task using Celery or some background task scheduler.
        """
        from django_celery_beat.models import PeriodicTask, IntervalSchedule
        if not self.reminder_set:
            schedule, created = IntervalSchedule.objects.get_or_create(
                every=2,
                period=IntervalSchedule.MINUTES,
            )
            PeriodicTask.objects.create(
                interval=schedule,                  # execute every 2 minutes
                name=f"Reminder for task {self.pk}", # unique task name
                task='tasks.send_task_reminder',    # name of your Celery task
                args=[self.pk],                     # pass the task ID as argument
            )
            self.reminder_set = True
            self.save()
